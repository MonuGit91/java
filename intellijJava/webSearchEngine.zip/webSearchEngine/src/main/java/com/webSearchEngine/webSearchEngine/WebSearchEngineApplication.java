package com.webSearchEngine.webSearchEngine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebSearchEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebSearchEngineApplication.class, args);
	}

}
